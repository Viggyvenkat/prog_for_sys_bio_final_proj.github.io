import React, { useState, useCallback, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ROOMS, PUZZLES, INITIAL_INVENTORY, KNOWLEDGE_DATABASE } from '@/lib/gameData';
import TitleScreen from '@/components/game/TitleScreen';
import NarrativeDisplay from '@/components/game/NarrativeDisplay';
import ChoicePanel from '@/components/game/ChoicePanel';
import InventoryBar from '@/components/game/InventoryBar';
import RoomHeader from '@/components/game/RoomHeader';
import MatchingPuzzle from '@/components/game/MatchingPuzzle';
import ClassifyPuzzle from '@/components/game/ClassifyPuzzle';
import KnowledgeCodex from '@/components/game/KnowledgeCodex';
import { ScrollArea } from '@/components/ui/scroll-area';

const SAVE_KEY = 'nih_data_chronicles_save';

function loadSave() {
  const raw = localStorage.getItem(SAVE_KEY);
  if (!raw) return null;
  return JSON.parse(raw);
}

function saveToDisk(state) {
  localStorage.setItem(SAVE_KEY, JSON.stringify(state));
}

function createNewState() {
  return {
    currentRoom: 'intro',
    inventory: [...INITIAL_INVENTORY],
    visitedRooms: ['intro'],
    puzzlesSolved: [],
    knowledgeUnlocked: [],
    score: 0,
  };
}

export default function Game() {
  const [gameState, setGameState] = useState(null);
  const [showTitle, setShowTitle] = useState(true);
  const [showCodex, setShowCodex] = useState(false);
  const [puzzleActive, setPuzzleActive] = useState(false);
  const [roomKey, setRoomKey] = useState(0);
  const scrollRef = useRef(null);

  const hasSave = !!loadSave();

  const startNewGame = useCallback(() => {
    const newState = createNewState();
    setGameState(newState);
    saveToDisk(newState);
    setShowTitle(false);
    setRoomKey(k => k + 1);
  }, []);

  const continueGame = useCallback(() => {
    const saved = loadSave();
    if (saved) {
      setGameState(saved);
      setShowTitle(false);
      setRoomKey(k => k + 1);
    }
  }, []);

  const updateState = useCallback((updates) => {
    setGameState(prev => {
      const next = { ...prev, ...updates };
      saveToDisk(next);
      return next;
    });
  }, []);

  const handleChoice = useCallback((choice) => {
    if (choice.resetGame) {
      startNewGame();
      return;
    }

    const nextRoom = choice.nextRoom;
    const newKnowledge = [...gameState.knowledgeUnlocked];
    if (choice.knowledge && !newKnowledge.includes(choice.knowledge)) {
      newKnowledge.push(choice.knowledge);
    }

    const newVisited = [...gameState.visitedRooms];
    if (!newVisited.includes(nextRoom)) {
      newVisited.push(nextRoom);
    }

    updateState({
      currentRoom: nextRoom,
      visitedRooms: newVisited,
      knowledgeUnlocked: newKnowledge,
    });

    setPuzzleActive(false);
    setRoomKey(k => k + 1);

    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [gameState, updateState, startNewGame]);

  const handlePuzzleComplete = useCallback((perfect, correctCount) => {
    const room = ROOMS[gameState.currentRoom];
    const puzzleId = room.puzzle;
    const puzzle = PUZZLES[puzzleId];

    const newSolved = [...gameState.puzzlesSolved];
    if (!newSolved.includes(puzzleId)) {
      newSolved.push(puzzleId);
    }

    const newKnowledge = [...gameState.knowledgeUnlocked];
    if (puzzle.knowledge && !newKnowledge.includes(puzzle.knowledge)) {
      newKnowledge.push(puzzle.knowledge);
    }

    const scoreGain = perfect ? puzzle.scoreValue : Math.floor(puzzle.scoreValue * (correctCount / puzzle.pairs?.length || puzzle.items?.length));

    updateState({
      puzzlesSolved: newSolved,
      knowledgeUnlocked: newKnowledge,
      score: gameState.score + scoreGain,
    });
  }, [gameState, updateState]);

  useEffect(() => {
    if (gameState) {
      const room = ROOMS[gameState.currentRoom];
      if (room?.puzzle && !gameState.puzzlesSolved.includes(room.puzzle)) {
        setPuzzleActive(true);
      } else {
        setPuzzleActive(false);
      }
    }
  }, [gameState?.currentRoom]);

  if (showTitle) {
    return <TitleScreen onStart={startNewGame} hasSave={hasSave} onContinue={continueGame} />;
  }

  if (!gameState) return null;

  const room = ROOMS[gameState.currentRoom];
  if (!room) return null;

  const puzzle = room.puzzle ? PUZZLES[room.puzzle] : null;
  const puzzleAlreadySolved = room.puzzle && gameState.puzzlesSolved.includes(room.puzzle);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top bar */}
      <div className="sticky top-0 z-40 bg-background/90 backdrop-blur-md border-b border-border px-4 py-3">
        <InventoryBar
          inventory={gameState.inventory}
          knowledgeCount={gameState.knowledgeUnlocked.length}
          score={gameState.score}
          onToggleCodex={() => setShowCodex(true)}
        />
      </div>

      {/* Main game area */}
      <div className="flex-1 flex justify-center">
        <div className="w-full max-w-3xl px-4 py-6">
          <RoomHeader
            visitedRooms={gameState.visitedRooms.length}
            puzzlesSolved={gameState.puzzlesSolved.length}
          />

          <AnimatePresence mode="wait">
            <motion.div
              key={roomKey}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.4 }}
              className="space-y-6 mt-4"
            >
              {/* Narrative */}
              <div className="p-5 rounded-xl border border-border bg-card/50">
                <NarrativeDisplay title={room.title} text={room.narrative} />
              </div>

              {/* Codex entries display (for codex room) */}
              {room.isCodex && gameState.knowledgeUnlocked.length > 0 && (
                <div className="p-5 rounded-xl border border-border bg-card/50 space-y-3">
                  <div className="text-xs font-mono uppercase tracking-widest text-primary">
                    // Unlocked Entries
                  </div>
                  {gameState.knowledgeUnlocked.map(key => {
                    const entry = KNOWLEDGE_DATABASE[key];
                    if (!entry) return null;
                    const isKF = key.startsWith('kf_');
                    return (
                      <div
                        key={key}
                        className={`p-3 rounded border ${
                          isKF
                            ? 'border-blue-500/20 bg-blue-500/5'
                            : 'border-green-500/20 bg-green-500/5'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-mono uppercase tracking-wider ${
                            isKF ? 'text-blue-400' : 'text-green-400'
                          }`}>
                            {entry.program}
                          </span>
                        </div>
                        <div className="text-xs font-mono font-semibold text-foreground mt-1">{entry.title}</div>
                        <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{entry.description}</p>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Puzzle */}
              {puzzle && puzzleActive && !puzzleAlreadySolved && (
                <div className="p-5 rounded-xl border border-primary/20 bg-primary/5">
                  {puzzle.type === 'matching' ? (
                    <MatchingPuzzle puzzle={puzzle} onComplete={handlePuzzleComplete} />
                  ) : (
                    <ClassifyPuzzle puzzle={puzzle} onComplete={handlePuzzleComplete} />
                  )}
                </div>
              )}

              {puzzleAlreadySolved && puzzle && (
                <div className="p-4 rounded-xl border border-accent/30 bg-accent/5 text-xs font-mono text-accent">
                  ✓ Puzzle "{puzzle.title}" already completed.
                </div>
              )}

              {/* Choices */}
              <div className="p-5 rounded-xl border border-border bg-card/30">
                <ChoicePanel choices={room.choices} onChoice={handleChoice} />
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Scanline effect */}
      <div className="fixed inset-0 pointer-events-none z-30 opacity-[0.02]"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,200,0.03) 2px, rgba(0,255,200,0.03) 4px)'
        }}
      />

      {/* Codex Modal */}
      {showCodex && (
        <KnowledgeCodex
          unlockedKeys={gameState.knowledgeUnlocked}
          onClose={() => setShowCodex(false)}
        />
      )}
    </div>
  );
}