import React from 'react';
import { Scan, Map, Database, BookOpen } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const ITEM_ICONS = {
  "Data Sequencer": Scan,
  "Atlas Mapper": Map,
};

export default function InventoryBar({ inventory, knowledgeCount, score, onToggleCodex }) {
  return (
    <div className="flex items-center justify-between gap-4 px-4 py-2.5 bg-secondary/50 border border-border rounded-lg">
      <div className="flex items-center gap-3">
        <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
          Inventory
        </div>
        <div className="flex items-center gap-2">
          {inventory.map((item) => {
            const Icon = ITEM_ICONS[item] || Database;
            return (
              <div
                key={item}
                className="flex items-center gap-1.5 px-2 py-1 bg-card border border-border rounded text-xs font-mono text-foreground"
              >
                <Icon className="w-3 h-3 text-primary" />
                {item}
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={onToggleCodex}
          className="flex items-center gap-1.5 px-2 py-1 bg-card border border-border rounded text-xs font-mono text-foreground hover:border-primary/50 hover:text-primary transition-colors"
        >
          <BookOpen className="w-3 h-3" />
          Codex
          <Badge variant="secondary" className="ml-1 h-4 px-1.5 text-[10px] bg-primary/10 text-primary">
            {knowledgeCount}
          </Badge>
        </button>

        <div className="flex items-center gap-1.5 px-2 py-1 text-xs font-mono">
          <span className="text-muted-foreground">Score:</span>
          <span className="text-primary font-semibold">{score}</span>
        </div>
      </div>
    </div>
  );
}