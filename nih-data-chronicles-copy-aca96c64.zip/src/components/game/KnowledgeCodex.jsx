import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Dna, FlaskConical } from 'lucide-react';
import { KNOWLEDGE_DATABASE } from '@/lib/gameData';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function KnowledgeCodex({ unlockedKeys, onClose }) {
  const kfEntries = Object.entries(KNOWLEDGE_DATABASE).filter(([k]) => k.startsWith('kf_') && unlockedKeys.includes(k));
  const sennetEntries = Object.entries(KNOWLEDGE_DATABASE).filter(([k]) => k.startsWith('sennet_') && unlockedKeys.includes(k));

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm"
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="w-full max-w-2xl max-h-[80vh] bg-card border border-border rounded-xl overflow-hidden shadow-2xl"
        >
          <div className="flex items-center justify-between p-4 border-b border-border">
            <div>
              <h3 className="font-mono text-sm font-semibold text-foreground uppercase tracking-wider">
                Data Codex
              </h3>
              <p className="text-xs text-muted-foreground font-mono mt-0.5">
                {unlockedKeys.length} / {Object.keys(KNOWLEDGE_DATABASE).length} entries unlocked
              </p>
            </div>
            <button onClick={onClose} className="p-1.5 rounded hover:bg-secondary transition-colors">
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>

          <ScrollArea className="h-[60vh] p-4">
            {unlockedKeys.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground font-mono text-sm">
                No entries unlocked yet. Explore the station to discover data concepts.
              </div>
            ) : (
              <div className="space-y-6">
                {kfEntries.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Dna className="w-4 h-4 text-blue-400" />
                      <span className="text-xs font-mono uppercase tracking-widest text-blue-400">
                        Kids First Data Resource
                      </span>
                    </div>
                    <div className="space-y-2">
                      {kfEntries.map(([key, entry]) => (
                        <div key={key} className="p-3 rounded border border-blue-500/20 bg-blue-500/5">
                          <div className="text-xs font-mono font-semibold text-foreground">{entry.title}</div>
                          <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{entry.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {sennetEntries.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <FlaskConical className="w-4 h-4 text-green-400" />
                      <span className="text-xs font-mono uppercase tracking-widest text-green-400">
                        SenNet — Cellular Senescence Network
                      </span>
                    </div>
                    <div className="space-y-2">
                      {sennetEntries.map(([key, entry]) => (
                        <div key={key} className="p-3 rounded border border-green-500/20 bg-green-500/5">
                          <div className="text-xs font-mono font-semibold text-foreground">{entry.title}</div>
                          <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{entry.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </ScrollArea>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}