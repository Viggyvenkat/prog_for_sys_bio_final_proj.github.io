import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';

export default function ChoicePanel({ choices, onChoice }) {
  return (
    <div className="space-y-3">
      <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
        // Select Action
      </div>
      {choices.map((choice, index) => (
        <motion.button
          key={choice.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.15, duration: 0.3 }}
          onClick={() => onChoice(choice)}
          className="w-full text-left group"
        >
          <div className="border border-border hover:border-primary/60 rounded-lg p-4 transition-all duration-300 hover:bg-primary/5 group-hover:shadow-[0_0_20px_rgba(0,255,200,0.05)]">
            <div className="flex items-start gap-3">
              <div className="mt-0.5 w-6 h-6 rounded border border-primary/40 flex items-center justify-center shrink-0 group-hover:bg-primary group-hover:border-primary transition-all">
                <ChevronRight className="w-3.5 h-3.5 text-primary group-hover:text-primary-foreground transition-colors" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-mono text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
                  {choice.label}
                </div>
                <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                  {choice.description}
                </p>
              </div>
            </div>
          </div>
        </motion.button>
      ))}
    </div>
  );
}