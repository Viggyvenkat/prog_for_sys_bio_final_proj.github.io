import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, X, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ClassifyPuzzle({ puzzle, onComplete }) {
  const [classifications, setClassifications] = useState({});
  const [results, setResults] = useState(null);
  const [explanations, setExplanations] = useState([]);

  const classes = Object.keys(puzzle.classLabels);

  const handleClassify = (itemText, classKey) => {
    if (results) return;
    setClassifications(prev => ({ ...prev, [itemText]: classKey }));
  };

  const checkAnswers = () => {
    let correct = 0;
    const exps = [];
    puzzle.items.forEach(item => {
      const isCorrect = classifications[item.item] === item.correctClass;
      if (isCorrect) correct++;
      exps.push({
        item: item.item,
        correct: isCorrect,
        correctClass: puzzle.classLabels[item.correctClass],
        userClass: classifications[item.item] ? puzzle.classLabels[classifications[item.item]] : "None",
        explanation: item.explanation
      });
    });
    setResults({ correct, total: puzzle.items.length });
    setExplanations(exps);
    onComplete(correct === puzzle.items.length, correct);
  };

  const allClassified = Object.keys(classifications).length === puzzle.items.length;

  return (
    <div className="space-y-4">
      <div className="text-xs font-mono uppercase tracking-widest text-primary mb-1">
        // Puzzle: {puzzle.title}
      </div>
      <p className="text-xs text-muted-foreground font-mono">{puzzle.description}</p>

      {!results ? (
        <>
          <div className="flex gap-2 mb-3">
            {classes.map(cls => (
              <div
                key={cls}
                className="px-3 py-1.5 rounded border border-border text-xs font-mono text-muted-foreground"
              >
                {puzzle.classLabels[cls]}
              </div>
            ))}
          </div>

          <div className="space-y-2">
            {puzzle.items.map((item) => (
              <div
                key={item.item}
                className="p-3 rounded border border-border bg-card"
              >
                <div className="text-xs font-mono text-foreground mb-2">{item.item}</div>
                <div className="flex gap-2">
                  {classes.map(cls => (
                    <button
                      key={cls}
                      onClick={() => handleClassify(item.item, cls)}
                      className={`px-3 py-1 rounded text-[11px] font-mono transition-all border ${
                        classifications[item.item] === cls
                          ? 'border-primary bg-primary/15 text-primary'
                          : 'border-border hover:border-primary/40 text-muted-foreground'
                      }`}
                    >
                      {puzzle.classLabels[cls]}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <Button
            onClick={checkAnswers}
            disabled={!allClassified}
            className="w-full font-mono"
          >
            <Zap className="w-4 h-4 mr-2" />
            Run Classification Protocol
          </Button>
        </>
      ) : (
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-3"
          >
            <div className={`p-3 rounded border text-sm font-mono ${
              results.correct === results.total
                ? 'border-accent bg-accent/10 text-accent'
                : 'border-destructive/40 bg-destructive/10 text-destructive'
            }`}>
              {results.correct === results.total
                ? `✓ All ${results.total} classifications verified. System repaired.`
                : `${results.correct}/${results.total} correct. Partial repair achieved.`}
            </div>

            {explanations.map((exp, i) => (
              <div key={i} className="p-3 rounded border border-border bg-card text-xs font-mono space-y-1">
                <div className="flex items-center gap-2">
                  {exp.correct
                    ? <Check className="w-3.5 h-3.5 text-accent shrink-0" />
                    : <X className="w-3.5 h-3.5 text-destructive shrink-0" />
                  }
                  <span className="text-foreground font-semibold">{exp.item}</span>
                </div>
                {!exp.correct && (
                  <div className="text-destructive/80 ml-5">
                    Your answer: {exp.userClass} → Correct: {exp.correctClass}
                  </div>
                )}
                <p className="text-muted-foreground ml-5 leading-relaxed">{exp.explanation}</p>
              </div>
            ))}
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
}