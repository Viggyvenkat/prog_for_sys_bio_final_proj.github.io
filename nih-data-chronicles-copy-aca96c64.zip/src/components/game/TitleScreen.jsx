import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Play, BookOpen } from 'lucide-react';

export default function TitleScreen({ onStart, hasSave, onContinue }) {
  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="text-center max-w-lg"
      >
        <div className="mb-8">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-[10px] font-mono uppercase tracking-[0.4em] text-muted-foreground mb-4"
          >
            National Institutes of Health
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-4xl md:text-5xl font-mono font-bold text-foreground leading-tight"
          >
            The NIH
            <br />
            <span className="text-primary">Data Chronicles</span>
          </motion.h1>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="mt-4 h-px w-32 mx-auto bg-gradient-to-r from-transparent via-primary to-transparent"
          />

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
            className="mt-6 text-sm font-mono text-muted-foreground leading-relaxed max-w-md mx-auto"
          >
            A text-based adventure exploring the Gabriella Miller Kids First
            Data Resource and the Cellular Senescence Network (SenNet).
            <br /><br />
            You are a Bio-Data Guardian. Two critical data streams are failing.
            Only you can restore them.
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="space-y-3"
        >
          <Button
            onClick={onStart}
            size="lg"
            className="w-full max-w-xs font-mono text-sm"
          >
            <Play className="w-4 h-4 mr-2" />
            New Mission
          </Button>

          {hasSave && (
            <Button
              onClick={onContinue}
              variant="outline"
              size="lg"
              className="w-full max-w-xs font-mono text-sm"
            >
              <BookOpen className="w-4 h-4 mr-2" />
              Continue Mission
            </Button>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="mt-12 space-y-2"
        >
          <div className="text-[10px] font-mono text-muted-foreground/50 tracking-wider">
            FEATURING DATA FROM
          </div>
          <div className="flex items-center justify-center gap-6">
            <span className="text-xs font-mono text-blue-400/70">● Kids First</span>
            <span className="text-xs font-mono text-green-400/70">● SenNet</span>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}