import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

export default function NarrativeDisplay({ title, text }) {
  const [displayedText, setDisplayedText] = useState("");
  const [isComplete, setIsComplete] = useState(false);
  const intervalRef = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    setDisplayedText("");
    setIsComplete(false);
    let index = 0;

    intervalRef.current = setInterval(() => {
      if (index < text.length) {
        setDisplayedText(text.slice(0, index + 1));
        index++;
      } else {
        clearInterval(intervalRef.current);
        setIsComplete(true);
      }
    }, 8);

    return () => clearInterval(intervalRef.current);
  }, [text]);

  const skipAnimation = () => {
    clearInterval(intervalRef.current);
    setDisplayedText(text);
    setIsComplete(true);
  };

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [displayedText]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="relative"
    >
      <div className="flex items-center gap-3 mb-4">
        <div className="h-px flex-1 bg-gradient-to-r from-primary/50 to-transparent" />
        <h2 className="text-sm font-mono uppercase tracking-[0.2em] text-primary font-semibold">
          {title}
        </h2>
        <div className="h-px flex-1 bg-gradient-to-l from-primary/50 to-transparent" />
      </div>

      <div
        ref={containerRef}
        className="font-mono text-sm leading-relaxed text-foreground/90 max-h-[40vh] overflow-y-auto pr-2 whitespace-pre-line scrollbar-thin"
        onClick={!isComplete ? skipAnimation : undefined}
        style={{ cursor: !isComplete ? 'pointer' : 'default' }}
      >
        {displayedText}
        {!isComplete && (
          <span className="inline-block w-2 h-4 bg-primary ml-0.5 animate-pulse" />
        )}
      </div>

      {!isComplete && (
        <button
          onClick={skipAnimation}
          className="mt-2 text-xs font-mono text-muted-foreground hover:text-primary transition-colors"
        >
          [CLICK TO SKIP]
        </button>
      )}
    </motion.div>
  );
}