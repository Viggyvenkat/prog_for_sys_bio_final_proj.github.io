import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, X, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function MatchingPuzzle({ puzzle, onComplete }) {
  const [selectedTrait, setSelectedTrait] = useState(null);
  const [matches, setMatches] = useState({});
  const [results, setResults] = useState(null);
  const [explanations, setExplanations] = useState([]);

  const traits = puzzle.pairs.map(p => p.trait);
  const targets = [...puzzle.pairs.map(p => p.match)].sort(() => Math.random() - 0.5);

  const handleTraitClick = (trait) => {
    if (results) return;
    setSelectedTrait(trait === selectedTrait ? null : trait);
  };

  const handleTargetClick = (target) => {
    if (results || !selectedTrait) return;
    setMatches(prev => ({ ...prev, [selectedTrait]: target }));
    setSelectedTrait(null);
  };

  const checkAnswers = () => {
    let correct = 0;
    const exps = [];
    puzzle.pairs.forEach(pair => {
      const isCorrect = matches[pair.trait] === pair.match;
      if (isCorrect) correct++;
      exps.push({
        trait: pair.trait,
        correct: isCorrect,
        correctMatch: pair.match,
        userMatch: matches[pair.trait],
        explanation: pair.explanation
      });
    });
    setResults({ correct, total: puzzle.pairs.length });
    setExplanations(exps);
    onComplete(correct === puzzle.pairs.length, correct);
  };

  const allMatched = Object.keys(matches).length === puzzle.pairs.length;

  return (
    <div className="space-y-4">
      <div className="text-xs font-mono uppercase tracking-widest text-primary mb-1">
        // Puzzle: {puzzle.title}
      </div>
      <p className="text-xs text-muted-foreground font-mono">{puzzle.description}</p>

      {!results ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                Traits / Observations
              </div>
              {traits.map(trait => (
                <button
                  key={trait}
                  onClick={() => handleTraitClick(trait)}
                  className={`w-full text-left p-3 rounded border text-xs font-mono transition-all ${
                    selectedTrait === trait
                      ? 'border-primary bg-primary/10 text-primary'
                      : matches[trait]
                        ? 'border-accent/40 bg-accent/5 text-accent'
                        : 'border-border hover:border-primary/40 text-foreground'
                  }`}
                >
                  {trait}
                  {matches[trait] && (
                    <div className="text-[10px] text-accent mt-1">→ {matches[trait]}</div>
                  )}
                </button>
              ))}
            </div>

            <div className="space-y-2">
              <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                Genomic / Clinical Context
              </div>
              {targets.map(target => {
                const isUsed = Object.values(matches).includes(target);
                return (
                  <button
                    key={target}
                    onClick={() => handleTargetClick(target)}
                    disabled={isUsed && !selectedTrait}
                    className={`w-full text-left p-3 rounded border text-xs font-mono transition-all ${
                      isUsed
                        ? 'border-accent/40 bg-accent/5 text-accent/60'
                        : selectedTrait
                          ? 'border-border hover:border-primary/40 text-foreground cursor-pointer'
                          : 'border-border text-foreground/60'
                    }`}
                  >
                    {target}
                  </button>
                );
              })}
            </div>
          </div>

          <Button
            onClick={checkAnswers}
            disabled={!allMatched}
            className="w-full font-mono"
          >
            <Zap className="w-4 h-4 mr-2" />
            Verify Linkages
          </Button>
        </>
      ) : (
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-3"
          >
            <div className={`p-3 rounded border text-sm font-mono ${
              results.correct === results.total
                ? 'border-accent bg-accent/10 text-accent'
                : 'border-destructive/40 bg-destructive/10 text-destructive'
            }`}>
              {results.correct === results.total
                ? `✓ All ${results.total} linkages verified. Archive repaired.`
                : `${results.correct}/${results.total} correct. Partial repair achieved.`}
            </div>

            {explanations.map((exp, i) => (
              <div key={i} className="p-3 rounded border border-border bg-card text-xs font-mono space-y-1">
                <div className="flex items-center gap-2">
                  {exp.correct
                    ? <Check className="w-3.5 h-3.5 text-accent shrink-0" />
                    : <X className="w-3.5 h-3.5 text-destructive shrink-0" />
                  }
                  <span className="text-foreground font-semibold">{exp.trait}</span>
                </div>
                {!exp.correct && (
                  <div className="text-destructive/80 ml-5">
                    Your answer: {exp.userMatch || "None"} → Correct: {exp.correctMatch}
                  </div>
                )}
                <p className="text-muted-foreground ml-5 leading-relaxed">{exp.explanation}</p>
              </div>
            ))}
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
}