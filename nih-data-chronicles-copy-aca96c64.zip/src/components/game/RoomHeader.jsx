import React from 'react';
import { Badge } from '@/components/ui/badge';

export default function RoomHeader({ visitedRooms, puzzlesSolved }) {
  return (
    <div className="flex items-center justify-between mb-1">
      <div className="flex items-center gap-3">
        <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
        <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-muted-foreground">
          The NIH Data Chronicles
        </span>
      </div>
      <div className="flex gap-2">
        <Badge variant="outline" className="text-[10px] font-mono border-border">
          Rooms: {visitedRooms}
        </Badge>
        <Badge variant="outline" className="text-[10px] font-mono border-border">
          Puzzles: {puzzlesSolved}
        </Badge>
      </div>
    </div>
  );
}